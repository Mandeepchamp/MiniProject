package ui;

import java.util.Map;
import java.util.Scanner;

import bean.Account;
import bean.Customer;
import bean.Tansaction;
import service.AccountServices;

public class CustomerAccount {
	static AccountServices as = new AccountServices();
	static Account ab;
	static Tansaction trans;
    //Create Account
	public static void createAccount() {
		 Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Customer Name: ");
        String cName = sc.next();
        System.out.println("Enter the Customer Address: ");
        String cAddress = sc.next();
        System.out.println("Enter the Customer Contact: ");
        long cContact = sc.nextLong();
        System.out.println("Enter the Customer Mail ID: ");
        String cMail = sc.next();
        Customer c = new Customer(cName,cAddress,cContact,cMail);
        Account a = new Account(c);
        Tansaction t = new Tansaction(a.getBalance());
        t.setTotalBalance(a.getBalance());
        as.storeTransaction(a.getAccountNo(),t);
       as.CreateAccountService(a.getAccountNo(),a);
        System.out.println(a);
    	System.out.println("YOUR ACCOUNT CREATED Successfully!!!");
    	System.out.println("__________WELECOME TO E-Wallet__________");
        
	}
	 
	// Show Account User Details
	public static void showAccount() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Account no");
         long l = sc.nextLong();
	      ab = as.showAccountBalance(l);
               
           System.out.println("Account No= "+ab.getAccountNo());
                System.out.println("Balance= "+ab.getBalance());
                System.out.println(ab.getC());
                System.out.println("*****************************Thankyou to use our service.******************************");
	}
	
	// Deposit Amount
	public static void depositAmount() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enetr the Account No:");
         long acc = sc.nextLong();
        System.out.println("Enter the Amount for Deposit");
         double dAm = sc.nextDouble();
           Account dpAc= as.showAccountBalance(acc);
         double balance = dpAc.getBalance() + dAm;
          dpAc.setBalance(balance);
          as.CreateAccountService(acc,dpAc);
          
          Tansaction t1 = new Tansaction(dAm,balance);
	           t1.setTotalBalance(balance);
	           t1.setDeposit(balance);
	           as.storeTransaction(acc,t1);
             System.out.println("Your Amount Successfully Added to your Account");
             System.out.println("*******************************Thankyou to use our service.******************************");
	}
	
	// Withraw Amount
	public static void withdrawAmount() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Account No:");
	     long acNo = sc.nextLong();
	     System.out.println("Enter the Ammount you Withdraw");
	     double wiAm = sc.nextDouble();
	     Account wiAc = as.showAccountBalance(acNo);
	     if(wiAc.getBalance()>0.0||wiAc.getBalance()<wiAm) {
	    	 double newBalance = wiAc.getBalance() - wiAm;
	    	 wiAc.setBalance(newBalance);
		     as.CreateAccountService(acNo,wiAc);
		     
		     Tansaction t2 = new Tansaction(newBalance,wiAm,newBalance);
	           t2.setTotalBalance(newBalance);
	           t2.setWithdraw(wiAm);
	           as.storeTransaction(acNo,t2);
		     System.out.println("You Withdraw Rs:"+wiAm+"form your Account");
		     System.out.println("*******************************Thankyou to use our service.******************************");
	     }else {
	    	 System.out.println("***********************************InSuffficcent Balance***********************************************");
	     }
	}
	
	//Fund Transfer
	public static void fundTransfer() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Your Account No:");
		   long acccountNo1 = sc.nextLong();
		   System.out.println("Enter the Ammount you transfer");
		   double ammountTrans = sc.nextDouble();
		   System.out.println("Enter the Transfer Account No:");
		   long acccountNo2 = sc.nextLong();
		   Account account1 = as.showAccountBalance(acccountNo1 );
		   Account account2 = as.showAccountBalance(acccountNo2 );
		   if(account1.getBalance()>0.0) {
		    	 double newBalance = account1.getBalance() - ammountTrans;
		    	 account1.setBalance(newBalance);
			     as.CreateAccountService(acccountNo1,account1);
			     double accountbalance = account2.getBalance() + ammountTrans;
			     account2.setBalance(accountbalance);
	             as.CreateAccountService(acccountNo2,account2);
			     System.out.println("*******************************Thankyou to use our service.******************************");
			     }else {
			    	 System.out.println("***********************************InSuffficcent Balance***********************************************");
			     }
	}
	
	//Showing Transaction Details
	public static void printTransaction() {
		Scanner sc = new Scanner(System.in);
		 System.out.println("Enter the Account Number");
	     long accountNo2 = sc.nextLong();
	     trans = as.displayTransaction(accountNo2);
	      System.out.println(trans);
	}
	
   public static void main(String[] args){
	   System.out.println("______________________________E-Wallet______________________________");
	   Scanner sc = new Scanner(System.in);
	   String s;
	   do{
	   System.out.println("\n");
	   System.out.println("***********************Menu***********************");
	    System.out.print("|1.Create Account|            ");
	    System.out.print("|2.Show Balance|            ");
	    System.out.println("\n");
	    System.out.print("|3.Deposit|                   ");
	    System.out.print("|4.Withdraw|            ");
	    System.out.println("\n");
	    System.out.print("|5.Fund Transfer|             ");
	    System.out.print("|6.Print Transaction|            ");
	    System.out.println("\n");
	   System.out.println("Choose Option: ");
	   int ch =sc.nextInt();
	  
	   switch(ch){
	   case 1:   
		   //Create Account 
		   createAccount();
		     break;
	   case 2:  
		   //Show Account Details
		   showAccount();
		   break;
	   case 3: 
		   //Deposite Amount
		   depositAmount();
	       break;
	   case 4:     
		   //Withdraw Amount
		   withdrawAmount();
		   break;
	   case 5:
		   //Fund Transfer
		   fundTransfer();
 		   break;
	   case 6 : 
		   //Show Transaction Detials
		   printTransaction();
		   break;
		   default: System.out.println("Wrong Option");
	   }
	   System.out.println("\n");
	   System.out.println("If You Want continure :");
	    s = sc.next();
	   }while(s.equalsIgnoreCase("Y"));
   }
}
