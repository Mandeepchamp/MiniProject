package dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import bean.Account;
import bean.Tansaction;

public class AccountDao {
   
	static Map<Long,Account> list = new HashMap<Long,Account>();
    static Map<Long,Tansaction> transaction = new HashMap<Long,Tansaction>();
    
    public void createAccount(long ac,Account a){
    	list.put(ac,a);
    
    }
	public Account showBalance(long ac) {
	     Set<Long> s = list.keySet();
	     for(Long l :s){
	    	 if(l == ac){
	    		 return list.get(l);
	    	 }
	     }
		return null;
	}
	public void storeTrasactionDetails(long accountNo, Tansaction t) {
	  transaction.put(accountNo, t);	
		
	}
	public Tansaction showTRansaction(long accountNo2) {
		
		Set<Long> s = transaction.keySet();
	     for(Long l :s){
	    	 if(l == accountNo2){
	    		 return transaction.get(l);
	    	 }
	     }
		return null;
	}
}
