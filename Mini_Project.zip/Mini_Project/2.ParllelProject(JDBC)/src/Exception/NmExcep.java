package Exception;

public class NmExcep extends Exception{
private static final long serialVersionUID=1L;
String name;
public NmExcep(String name) {
	super();
	this.name=name;
}
}
