package ui;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.Scanner;

import Exception.NmExcep;
import data.DataClass;
import service.ServClass;
import service.ServInter;

public class uiClass {
private static String transferAmt;

public static void main(String[] args)throws NmExcep, SQLException {
	Scanner sc=new Scanner(System.in);
	long phone,account,acc2;
	String name;
	float avBal,bal,depAmt,withAmt,transAmt;
	int c;
	ServInter obj=new ServClass();
	 System.out.println("______________________________E-Wallet______________________________");
	  
	   String s;
	do {
		 System.out.println("\n");
		   System.out.println("***********************Menu***********************");
		    System.out.print("|1.Create Account|            ");
		    System.out.print("|2.Show Balance|            ");
		    System.out.println("\n");
		    System.out.print("|3.Deposit|                   ");
		    System.out.print("|4.Withdraw|            ");
		    System.out.println("\n");
		    System.out.print("|5.Fund Transfer|             ");
		    System.out.print("|6.Print Transaction|            ");
		    System.out.println("\n");
		System.out.println("enter your choice:");
		c=sc.nextInt();
		switch(c)
		{
		case 1:try{
			System.out.println("create account:");
		    DataClass dc=new DataClass();
		    System.out.println("Enter Name:");
		    name=sc.next();
		    obj.nameCheck(name);
			dc.setName(name);
			System.out.println("Enter Phone Number:");
		    phone=sc.nextLong();
			dc.setBal(0L);
			account=phone-9999;
			dc.setAccount(account);
			dc.setPhone(phone);
			obj.createAccount(dc);
		    
		    System.out.println("YOUR ACCOUNT CREATED Successfully!!!");
		    System.out.println("Account created with Account Number:"+account);
	    	System.out.println("__________WELECOME TO E-Wallet__________");
		   }catch(NmExcep e)
		    {
				System.out.println("invalid details");
		    }
		    break;
		case 2:System.out.println("balance enquiry");
		       System.out.println("enter account number:");
		       account=sc.nextLong();
		       avBal=obj.checkBal(account);
		       System.out.println("account balance is:"+avBal);
		       break;
		case 3:System.out.println("deposit");
		System.out.println("enter account number:");
	       account=sc.nextLong();
	       System.out.println("enter amount to be deposited:");
	       depAmt=sc.nextFloat();
	       bal=obj.deposit(account,depAmt);
	       System.out.println("balance:"+bal);
	       break;
		case 4:System.out.println("withdraw");
		System.out.println("enter account number:");
	       account=sc.nextLong();
	       System.out.println("enter withdrawing amount:");
	       withAmt=sc.nextFloat();
	       bal=obj.withdraw(withAmt,account);
	       System.out.println("amount withdrwan");
	       System.out.println("balance after withdrwaing:"+bal);
	       break;
		case 5:System.out.println("transfer");
		System.out.println("enter account number:");
	       account=sc.nextLong();
	       System.out.println("enetre receiver acc");
	       acc2=sc.nextLong();
	       System.out.println("enter amount you want to transfer:");
	       transAmt=sc.nextFloat();
	       bal=obj.transfer(account,acc2,transAmt);
	       System.out.println("amount transferred");
	       System.out.println("balance after transfer:"+bal);
	       try {
		   String transaction=transferAmt+"transferred from"+account+"to"+acc2;
	       new DataClass(transaction);
	       }catch(Exception e) {
	    	   System.out.println("receiver account dose not exist");
	       }
		break;
		case 6:System.out.println("transaction");
		System.out.println("transaction:");
		System.out.println(Arrays.toString(DataClass.transaction));
		break;
		case 7:System.out.println("thankyou");
		System.exit(0);
		}
		 System.out.println("If You Want continure :");
		    s = sc.next();
	}while(s.equalsIgnoreCase("Y"));
	sc.close();
}
}
