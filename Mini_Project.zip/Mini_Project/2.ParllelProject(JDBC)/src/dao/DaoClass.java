package dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import data.DataClass;

public class DaoClass implements DaoInter {
	DataClass dc;
	@Override
	public boolean custInfo(DataClass dc) {
		Connection con=null;
		boolean b=false;
 
		try {
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg516","training516");
			String sql="insert into DataClass values('"+dc.getName()+"',"+dc.getAccount()+","+dc.getBal()+","+dc.getPhone()+")";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			b=true;
			con.close();
		}catch(SQLException e) {
		e.printStackTrace();	
		}
		return b;
	}
	@Override
	public float checkBal(Long account)
	{
		Connection con=null;
		Long Newbalance=0L;
		try {
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg516","training516");
			String sql1="select ACCOUNT_NO from DataClass";
			PreparedStatement ps1=con.prepareStatement(sql1);
			ResultSet rs1=ps1.executeQuery(sql1);
			while(rs1.next())
			{
				if(rs1.getLong("ACCOUNT_NO")==account)
				{
					break;
				}
				else
					Newbalance=null;
			}
			String sql="select BALANCE from DataClass where ACCOUNT_NO="+account;
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery(sql);
			
			while(rs.next())
			{
				Newbalance=rs.getLong("BALANCE");
				rs.next();
		}
			con.close();
			}catch(SQLException e) {
 
		}
		return Newbalance;
	}
	@Override
	public float withAm(float withAt, long account) throws SQLException
	{
 
		Connection con=null;
		Long Newbalance=0L;
		try {
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg516","training516");
		    String sql1="select * from DataClass";
			PreparedStatement ps1=con.prepareStatement(sql1);
			ResultSet rs1=ps1.executeQuery(sql1);
			while(rs1.next())
			{
				if(rs1.getLong("ACCOUNT_NO")==account)
				{
					break;
 
				}
				else 
				{
					Newbalance=null;
				}
			}
 
			String sql="update DataClass set BALANCE=BALANCE-"+withAt+" where ACCOUNT_NO="+account;
			PreparedStatement ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			
			String s="select BALANCE from DataClass where ACCOUNT_NO="+account;
			PreparedStatement p=con.prepareStatement(s);
			ResultSet rs=p.executeQuery(s);
			while(rs.next())
			{
			Newbalance=rs.getLong("BALANCE");	
			}
			con.close();
 
	}
		catch(SQLException e)
		{
			throw e;
		}
		return Newbalance;
	}
	@Override
	public float transfer(long account, long acc2, float transAmt)
	{
		Connection con=null;
		Long Newbalance=0L;
		try {
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg516","training516");
			String sql1="select ACCOUNT_NO from DataClass";
			PreparedStatement ps1=con.prepareStatement(sql1);
			ResultSet rs1=ps1.executeQuery(sql1);
			while(rs1.next())
			{
				if(rs1.getLong("ACCOUNT_NO")==account)
				{
					break;
				}
				else {
					Newbalance=null;
				throw new SQLException();
			}
			}
		String sql="update DataClass set BALANCE=BALANCE-"+transAmt+" where ACCOUNT_NO="+account;
		PreparedStatement ps=con.prepareStatement(sql);
		ps.executeUpdate(sql);
 
		String sql2="select ACCOUNT_NO from DataClass";
		PreparedStatement ps2=con.prepareStatement(sql2);
		ResultSet rs2=ps2.executeQuery(sql2);
		while(rs2.next())
		{
			if(rs2.getLong("ACCOUNT_NO")==acc2)
			{
				break;
			}
			else {
				Newbalance=null;
			throw new SQLException();
 
		}}
		String s="update DataClass set BALANCE=BALANCE+"+transAmt+" where ACCOUNT_NO="+acc2;
		PreparedStatement p=con.prepareStatement(s);
		p.executeUpdate(s);
 
		String s2="select BALANCE from DataClass where ACCOUNT_NO="+account;
		PreparedStatement p2=con.prepareStatement(s2);
		ResultSet rs=p2.executeQuery(s2);
		while(rs.next())
		{
		Newbalance=rs.getLong("BALANCE");	
		}
		con.close();
 
}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	return Newbalance;
}
	@Override
	public float depoAmt(long account, float depAmt) 
	{
		Connection con=null;
		Long Newbalance=0L;
		try {
		con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg516","training516");
		
		String sql="update DataClass set BALANCE=BALANCE+"+depAmt+" where ACCOUNT_NO= "+account;
		PreparedStatement ps=con.prepareStatement(sql);
		ps.executeUpdate(sql);
		
		String s2="select BALANCE from DataClass where ACCOUNT_NO="+account;
		PreparedStatement p2=con.prepareStatement(s2);
		ResultSet rs=p2.executeQuery(s2);
		while(rs.next())
		{
		Newbalance=rs.getLong("BALANCE");	
		}
		con.close();
 
}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	return Newbalance;
	}
}
 
